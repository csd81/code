#include "verseny.h"
