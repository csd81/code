#ifndef VERSENY_H
#define VERSENY_H

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

#include "probalkozas.h"

class Verseny
{
};

#endif // VERSENY_H
