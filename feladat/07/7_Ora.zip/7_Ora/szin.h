#ifndef SZIN_H
#define SZIN_H

#include <string>

using namespace std;

class Szin
{
public:
};

#endif // SZIN_H
