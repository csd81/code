#ifndef HATARIDO_H
#define HATARIDO_H

#include "datum.h"

class Hatarido : public Datum
{
public:
    Hatarido();
};

#endif // HATARIDO_H
