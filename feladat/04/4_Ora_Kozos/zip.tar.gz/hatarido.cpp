#include "hatarido.h"

Hatarido::Hatarido() {}
