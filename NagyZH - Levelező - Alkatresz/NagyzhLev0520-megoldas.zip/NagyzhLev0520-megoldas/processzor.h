#ifndef PROCESSZOR_H
#define PROCESSZOR_H

#include "alkatresz.h"

class Processzor : public Alkatresz
{
	int orajel, magok;
public:
	Processzor(const string &_gyarto, const string &_tipus, int _orejel, int _magok);
	int getOrajel() const;
	int getMagok() const;
	int ar() const override;
};

#endif // PROCESSZOR_H
