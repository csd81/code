#ifndef KUPON_H
#define KUPON_H

#include "alkatresz.h"

template<class Tipus>
class Kupon
{
	int kedvezmeny;
public:
	Kupon(int _kedvezmeny):
		kedvezmeny(_kedvezmeny)
	{}
	int getKedvezmeny() const{
		return kedvezmeny;
	}
	int alkalmaz(Alkatresz *a) const{
		if (dynamic_cast<Tipus*>(a)) return a->ar()-kedvezmeny;
		else return a->ar();
	}
};

#endif // KUPON_H
