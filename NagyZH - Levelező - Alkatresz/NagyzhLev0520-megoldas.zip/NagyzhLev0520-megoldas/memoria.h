#ifndef MEMORIA_H
#define MEMORIA_H

#include "alkatresz.h"

class Memoria : public Alkatresz
{
	int kapacitas, sebesseg;
public:
	Memoria(const string &_gyarto, const string &_tipus, int _kapacitas=16, int _sebesseg=3200);
	int getKapacitas() const;
	int getSebesseg() const;
	int ar() const override;
};

#endif // MEMORIA_H
