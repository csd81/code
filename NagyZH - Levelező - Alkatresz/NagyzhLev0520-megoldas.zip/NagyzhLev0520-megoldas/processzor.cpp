#include "processzor.h"

Processzor::Processzor(const string &_gyarto, const string &_tipus, int _orejel, int _magok):
	Alkatresz(_gyarto, _tipus),
	orajel(_orejel),
	magok(_magok)
{
}

int Processzor::getOrajel() const
{
	return orajel;
}

int Processzor::getMagok() const
{
	return magok;
}

int Processzor::ar() const
{
	return orajel * 11 + magok * 16000;
}
