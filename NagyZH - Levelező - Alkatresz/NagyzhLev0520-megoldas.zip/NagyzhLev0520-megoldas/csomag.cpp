#include "csomag.h"

Csomag::Csomag(int _meret):
	Alkatresz("",""),
	meret(_meret),
	tomb(new Alkatresz*[meret]),
	aktualisDarab(0)
{
	for (int i=0; i<meret; i++)
		tomb[i]=nullptr;
}

Csomag::~Csomag()
{
	delete [] tomb;
}

int Csomag::ar() const
{
	int sum=0;
	for (int i=0; i<aktualisDarab; i++)
		sum+=tomb[i]->ar();
	return sum*0.9;
}

void Csomag::beallit(Alkatresz *a)
{
	if (aktualisDarab < meret)
		tomb[aktualisDarab++]=a;
}

int Csomag::darabszam() const
{
	return aktualisDarab;
}
