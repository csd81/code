#ifndef CSOMAG_H
#define CSOMAG_H

#include "alkatresz.h"

class Csomag : public Alkatresz
{
	int meret;
	Alkatresz **tomb;
	int aktualisDarab;
public:
	Csomag(int _meret);
	~Csomag();
	int ar() const override;
	void beallit(Alkatresz *a);
	int darabszam() const;
};

#endif // CSOMAG_H
