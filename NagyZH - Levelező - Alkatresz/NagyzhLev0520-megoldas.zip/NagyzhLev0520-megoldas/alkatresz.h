#ifndef ALKATRESZ_H
#define ALKATRESZ_H

#include <string>
#include <ostream>

using namespace std;

class Alkatresz
{
	string gyarto, tipus;
	static int ertekHatar;
public:
	Alkatresz(const string &_gyarto, const string &_tipus);
	virtual ~Alkatresz() = default;
	const string &getGyarto() const;
	const string &getTipus() const;

	virtual int ar() const = 0;
	virtual void kiir() const;

	bool operator<(int _ar) const;
	string operator!() const;

	static int getErtekHatar();
	static void setErtekHatar(int newErtekHatar);
	int teljesAr() const;
};

ostream &operator<<(ostream &os, const Alkatresz &a);

#endif // ALKATRESZ_H
