#include "egyebalkatresz.h"
#include <iostream>

EgyebAlkatresz::EgyebAlkatresz(const string &_gyarto, const string &_tipus, const string &_leiras, int _sajatAr):
	Alkatresz(_gyarto,_tipus),
	leiras(_leiras),
	sajatAr(_sajatAr)
{
}

const string &EgyebAlkatresz::getLeiras() const
{
	return leiras;
}

int EgyebAlkatresz::ar() const
{
	return sajatAr;
}

void EgyebAlkatresz::kiir() const
{
	cout << getGyarto() << " -- " << getTipus() << " (" << leiras << ") : " << ar() << endl;
}
