#include "alkatresz.h"
#include <iostream>

int Alkatresz::ertekHatar=450000;

Alkatresz::Alkatresz(const string &_gyarto, const string &_tipus):
	gyarto(_gyarto),
	tipus(_tipus)
{
}

const string &Alkatresz::getGyarto() const
{
	return gyarto;
}

const string &Alkatresz::getTipus() const
{
	return tipus;
}

void Alkatresz::kiir() const
{
	cout << gyarto << " -- " << tipus << " : " << ar() << endl;
}

bool Alkatresz::operator<(int _ar) const
{
	return ar() < _ar;
}

string Alkatresz::operator!() const
{
	return gyarto + " " + tipus;
}

int Alkatresz::getErtekHatar()
{
	return ertekHatar;
}

void Alkatresz::setErtekHatar(int newErtekHatar)
{
	ertekHatar = newErtekHatar;
}

int Alkatresz::teljesAr() const
{
	int a=ar();
	if (a<ertekHatar) return a;
	else if (a<ertekHatar*2) return a+14000;
	else return a+32000;
}

ostream &operator<<(ostream &os, const Alkatresz &a)
{
	os << a.getGyarto() << " -- " << a.getTipus() << " : " << a.ar();
	return os;
}
