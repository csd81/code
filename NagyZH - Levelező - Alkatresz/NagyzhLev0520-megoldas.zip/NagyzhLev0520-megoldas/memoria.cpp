#include "memoria.h"

Memoria::Memoria(const string &_gyarto, const string &_tipus, int _kapacitas, int _sebesseg):
	Alkatresz(_gyarto, _tipus),
	kapacitas(_kapacitas),
	sebesseg(_sebesseg)
{
}

int Memoria::getKapacitas() const
{
	return kapacitas;
}

int Memoria::getSebesseg() const
{
	return sebesseg;
}

int Memoria::ar() const
{
	return kapacitas * 800 + sebesseg * 7;
}
