#ifndef EGYEBALKATRESZ_H
#define EGYEBALKATRESZ_H

#include "alkatresz.h"

class EgyebAlkatresz : public Alkatresz
{
	string leiras;
	int sajatAr;
public:
	EgyebAlkatresz(const string &_gyarto, const string &_tipus, const string &_leiras, int _sajatAr);
	const string &getLeiras() const;
	int ar() const override;
	void kiir() const override;
};

#endif // EGYEBALKATRESZ_H
