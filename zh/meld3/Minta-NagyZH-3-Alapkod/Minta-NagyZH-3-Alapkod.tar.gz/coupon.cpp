#include "coupon.h"

Coupon::Coupon(int value)
    : value(value)
{}

Coupon::~Coupon()
{

}
