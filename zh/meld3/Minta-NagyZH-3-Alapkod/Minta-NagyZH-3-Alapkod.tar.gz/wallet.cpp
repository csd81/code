
#include <fstream>
#include <string>
#include <vector>
#include "singleusecoupon.h"
#include "multiusecoupon.h"
#include "monthlycoupon.h"
#include "wallet.h"
#include "json.hpp"
using namespace std;
using namespace nlohmann;

Wallet::Wallet()
{

}

void Wallet::loadCoupons(const std::string &file)
{
    ifstream in(file);
    json js;
    in >> js;

    for (auto& item : js){
        string type = item["type"];
        int value  = item["value"];

        if (type == "single"){
            addCoupon(new SingleUseCoupon(value));
        }
        else if (type == "multi"){
            int uses = item["uses"];
            addCoupon(new MultiUseCoupon(value, uses));
        }
        else if (type == "monthly"){
            int year = item["validYear"];
            int month = item["validMonth"];
            addCoupon(new MonthlyCoupon(year, month, value));
        }
    }
}






std::vector<Coupon *> Wallet::getCoupons() const
{
    return coupons;
}



void Wallet::addCoupon(Coupon* c)
{
    coupons.push_back(c);
}



void Wallet::listCoupons() const
{
    for (auto c : coupons){
        c->print();
    }
}



void Wallet::exportCounts(const std::string &file)
{
    json js;

    int singleValid =  countCoupons<SingleUseCoupon>(true);
    int singleTotal =  countCoupons<SingleUseCoupon>(false);
    int multiValid = countCoupons<MultiUseCoupon>(true);
    int multiTotal = countCoupons<MultiUseCoupon>(false);
    int monthlyValid = countCoupons<MonthlyCoupon>(true);
    int monthlyTotal = countCoupons<MonthlyCoupon>(false);

     js["Single"]["valid"] = singleValid;
     js["Single"]["invalid"] = singleTotal - singleValid;
     js["Multi"]["valid"] = multiValid;
     js["Multi"]["invalid"] = multiTotal - multiValid;
     js["Monthly"]["valid"] = monthlyValid;
     js["Monthly"]["invalid"] = monthlyTotal - monthlyValid;

    ofstream out(file);
    out << js.dump(4);
    out.close();
}




